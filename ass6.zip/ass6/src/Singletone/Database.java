package Singletone;

public class Database {
}
