package AbstractFactory;

public interface Chair {
    public void hasLegs();
    public void sitOn();
    public void hasSeats();
}
