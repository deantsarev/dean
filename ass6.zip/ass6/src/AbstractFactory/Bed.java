package AbstractFactory;

public interface Bed {
    public void hasLegs();
    public void hasLyingPlaces();
    public void sitOn();
    public void lieOn();
}