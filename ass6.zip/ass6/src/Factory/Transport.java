package Factory;

public interface Transport {
    public void deliver();
}
