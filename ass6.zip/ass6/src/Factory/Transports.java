package Factory;
//java enum to define transportation types
public enum Transports {
    TRUCK, SHIP, AIRPLANE
}
